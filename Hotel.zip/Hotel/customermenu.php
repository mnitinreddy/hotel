
<nav id="navbar"  class="navbar order-last order-lg-0">
            <ul>
              <li><a class="nav-link scrollto" href="CustomerHome.php">Home</a></li>
             
              <li><a class="nav-link scrollto" href="ViewCHotel.php">View Hotels</a></li>
              <li><a class="nav-link scrollto" href="BookingHistory.php">Booking History</a></li>
              <li><a class="nav-link scrollto" href="PaymentHistory.php">Payment History</a></li>
              <li><a class="nav-link scrollto" href="Feedback.php">Feedback</a></li>             
              <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
          </nav><!-- .navbar -->
