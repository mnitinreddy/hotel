<?php 
/*Creates a navigation bar with StaffHome, ViewSBooking, ViewSPayment, ViewStaffEvent,
ViewStaffHotelRooms, logout */
?>
<nav id="navbar"  class="navbar order-last order-lg-0">
            <ul>
              <li><a class="nav-link scrollto" href="StaffHome.php">Home</a></li>
              <li><a class="nav-link scrollto" href="ViewSBooking.php">View Booking</a></li>
              <li><a class="nav-link scrollto" href="ViewSPayment.php">Payment Details</a></li>
              <li><a class="nav-link scrollto" href="ViewStaffEvent.php">View Event</a></li>
              <li><a class="nav-link scrollto" href="ViewStaffHotelRooms.php">View Rooms</a></li>
              <li><a class="nav-link scrollto" href="logout.php">Logout</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
          </nav><!-- .navbar -->
    